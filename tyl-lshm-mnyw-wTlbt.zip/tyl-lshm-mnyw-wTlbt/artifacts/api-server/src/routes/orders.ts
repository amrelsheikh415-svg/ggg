import { getAuth } from "@clerk/express";
import { desc, eq } from "drizzle-orm";
import { Router, type IRouter, type NextFunction, type Request, type Response } from "express";
import {
  CreateOrderBody,
  CreateOrderResponse,
  ListOrdersResponse,
  UpdateOrderStatusBody,
  UpdateOrderStatusParams,
  UpdateOrderStatusResponse,
} from "@workspace/api-zod";
import { db, ordersTable, type OrderItemRecord } from "@workspace/db";

const router: IRouter = Router();

const catalog: Record<string, { name: string; price: number } | undefined> = {
  "potato-syrian": { name: "بطاطا سوري", price: 60 },
  "falafel-syrian": { name: "فلافل سوري", price: 60 },
  "mix-falafel-potato": { name: "مكس فلافل وبطاطا", price: 70 },
  "mix-potato-cheese": { name: "مكس بطاطا وجبنة", price: 70 },
  "harissa-cheese": { name: "هريسة مع جبنة", price: 50 },
  "chicken-shawarma": { name: "شاورما فراخ", price: 120 },
  "chicken-mozzarella": { name: "شاورما فراخ موزاريلا", price: 135 },
  "meat-shawarma": { name: "شاورما لحم", price: 150 },
  "chicken-burger": { name: "برجر فراخ", price: 120 },
  "kofta-sandwich": { name: "كفتة", price: 150 },
  "chicken-meal": { name: "وجبة شاورما فراخ سوري", price: 185 },
  "meat-meal": { name: "وجبة شاورما لحم", price: 220 },
  "crispy-meal": { name: "وجبة كرسبي", price: 0 },
  "kofta-meal": { name: "وجبة كفتة", price: 200 },
  "tila-mix": { name: "وجبة ميكس تيلا", price: 300 },
  pickles: { name: "علبة مخلل", price: 15 },
  garlic: { name: "علبة ثومية", price: 15 },
  masaha: { name: "مسحة", price: 50 },
  fries: { name: "باكيت بطاطا", price: 50 },
  "cheese-borek": { name: "بورك جبنة", price: 45 },
  "meat-borek": { name: "بورك لحم", price: 49 },
  kibbeh: { name: "كبة", price: 59 },
};

const allowedStatuses = new Set([
  "new",
  "accepted",
  "preparing",
  "ready",
  "completed",
  "cancelled",
]);

function requireStaff(req: Request, res: Response, next: NextFunction): void {
  const auth = getAuth(req);
  if (!auth.userId) {
    res.status(401).json({ error: "Staff sign-in required" });
    return;
  }

  const claims = auth.sessionClaims as { email?: unknown } | null;
  const email =
    typeof claims?.email === "string" ? claims.email.trim().toLowerCase() : "";
  const allowedEmails = (process.env.ADMIN_EMAILS ?? "")
    .split(",")
    .map((value) => value.trim().toLowerCase())
    .filter(Boolean);

  if (!email || !allowedEmails.includes(email)) {
    res.status(403).json({ error: "This account is not authorized to manage orders" });
    return;
  }

  next();
}

router.post("/orders", async (req, res): Promise<void> => {
  const parsed = CreateOrderBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "بيانات الطلب غير مكتملة أو غير صحيحة." });
    return;
  }

  const input = parsed.data;
  const customerName = input.customerName.trim();
  const phone = input.phone.trim();
  const address =
    input.fulfillment === "delivery" ? input.address?.trim() || null : null;

  if (customerName.length < 2 || phone.length < 7) {
    res.status(400).json({ error: "تحقق من الاسم ورقم الهاتف." });
    return;
  }
  if (input.fulfillment === "delivery" && !address) {
    res.status(400).json({ error: "عنوان التوصيل مطلوب." });
    return;
  }

  const orderItems: OrderItemRecord[] = [];
  for (const item of input.items) {
    const product = catalog[item.productId];
    if (!product) {
      res.status(400).json({ error: "أحد الأصناف لم يعد متاحًا في المنيو." });
      return;
    }

    let unitPrice = product.price;
    if (item.productId === "crispy-meal") {
      if (item.selectedPrice !== 200 && item.selectedPrice !== 250) {
        res.status(400).json({ error: "اختر سعر وجبة الكرسبي." });
        return;
      }
      unitPrice = item.selectedPrice;
    } else if (item.selectedPrice !== null) {
      res.status(400).json({ error: "سعر الصنف غير صالح." });
      return;
    }

    orderItems.push({
      productId: item.productId,
      name: product.name,
      quantity: item.quantity,
      unitPrice,
    });
  }

  const totalPrice = orderItems.reduce(
    (sum, item) => sum + item.unitPrice * item.quantity,
    0,
  );

  const [order] = await db
    .insert(ordersTable)
    .values({
      customerName,
      phone,
      address,
      fulfillment: input.fulfillment,
      items: orderItems,
      totalPrice,
      status: "new",
    })
    .returning();

  res.status(201).json(CreateOrderResponse.parse(order));
});

router.get("/orders", requireStaff, async (_req, res): Promise<void> => {
  const orders = await db
    .select()
    .from(ordersTable)
    .orderBy(desc(ordersTable.createdAt))
    .limit(200);

  res.json(ListOrdersResponse.parse(orders));
});

router.patch(
  "/orders/:id/status",
  requireStaff,
  async (req, res): Promise<void> => {
    const params = UpdateOrderStatusParams.safeParse(req.params);
    const body = UpdateOrderStatusBody.safeParse(req.body);
    if (!params.success || !body.success || !allowedStatuses.has(body.data.status)) {
      res.status(400).json({ error: "حالة الطلب غير صالحة." });
      return;
    }

    const [order] = await db
      .update(ordersTable)
      .set({ status: body.data.status, updatedAt: new Date() })
      .where(eq(ordersTable.id, params.data.id))
      .returning();

    if (!order) {
      res.status(404).json({ error: "الطلب غير موجود." });
      return;
    }

    res.json(UpdateOrderStatusResponse.parse(order));
  },
);

export default router;
