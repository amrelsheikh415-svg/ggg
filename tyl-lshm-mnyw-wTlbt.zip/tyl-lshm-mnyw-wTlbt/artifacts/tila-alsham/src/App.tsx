import { useEffect, useMemo, useState, type FormEvent, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ClerkProvider, SignIn, SignUp, useAuth, useClerk, useUser } from '@clerk/react';
import { publishableKeyFromHost } from '@clerk/react/internal';
import { shadcn } from '@clerk/themes';
import { getListOrdersQueryKey, useCreateOrder, useListOrders, useUpdateOrderStatus } from '@workspace/api-client-react';
import type { Order, OrderStatus } from '@workspace/api-client-react';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import {
  ArrowDown, ArrowLeft, Check, ChefHat, ChevronDown, CircleCheck, Clock3,
  Copy, MapPin, Minus, PackageCheck, Phone, Plus, RefreshCw, Share2,
  ShoppingBag, ShoppingBasket, Soup, Sparkles, Utensils, X, LogOut,
} from 'lucide-react';
import { Redirect, Route, Switch, useLocation, Router as WouterRouter } from 'wouter';

const queryClient = new QueryClient();
const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');
const clerkPubKey = publishableKeyFromHost(
  window.location.hostname,
  import.meta.env.VITE_CLERK_PUBLISHABLE_KEY,
);
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;

function stripBase(path: string) {
  return basePath && path.startsWith(basePath) ? path.slice(basePath.length) || '/' : path;
}

const clerkAppearance = {
  theme: shadcn,
  cssLayerName: 'clerk',
  options: {
    logoPlacement: 'inside' as const,
    logoLinkUrl: basePath || '/',
    logoImageUrl: `${window.location.origin}${basePath}/logo.svg`,
  },
  variables: {
    colorPrimary: '#df672d',
    colorForeground: '#172943',
    colorMutedForeground: '#73766f',
    colorDanger: '#a83b2a',
    colorBackground: '#faf8f1',
    colorInput: '#f8f6ef',
    colorInputForeground: '#172943',
    colorNeutral: '#d9d2c3',
    fontFamily: "'IBM Plex Sans Arabic', sans-serif",
    borderRadius: '2px',
  },
  elements: {
    rootBox: 'w-full flex justify-center',
    cardBox: 'bg-[#faf8f1] rounded-none w-[440px] max-w-full overflow-hidden border border-[#ded8ca]',
    card: '!shadow-none !border-0 !bg-transparent !rounded-none',
    footer: '!shadow-none !border-0 !bg-transparent !rounded-none',
    headerTitle: 'text-[#172943] font-semibold',
    headerSubtitle: 'text-[#73766f]',
    socialButtonsBlockButtonText: 'text-[#172943] font-medium',
    formFieldLabel: 'text-[#172943] font-medium',
    footerActionLink: 'text-[#b84d25] font-semibold',
    footerActionText: 'text-[#73766f]',
    dividerText: 'text-[#73766f]',
    identityPreviewEditButton: 'text-[#b84d25]',
    formFieldSuccessText: 'text-[#4e692d]',
    alertText: 'text-[#8f3928]',
    logoBox: 'rounded-none',
    logoImage: 'object-contain',
    socialButtonsBlockButton: 'rounded-none border-[#d9d2c3] bg-[#f5f1e7]',
    formButtonPrimary: 'rounded-none bg-[#172943] hover:bg-[#df672d]',
    formFieldInput: 'rounded-none border-[#d9d2c3] bg-[#f8f6ef] text-[#172943]',
    footerAction: 'text-[#73766f]',
    dividerLine: 'bg-[#ded8ca]',
    alert: 'rounded-none',
    otpCodeFieldInput: 'rounded-none border-[#d9d2c3]',
    formFieldRow: 'text-[#172943]',
    main: 'text-[#172943]',
  },
};

if (!clerkPubKey) throw new Error('Missing VITE_CLERK_PUBLISHABLE_KEY in .env file');

type Product = { id: string; name: string; price?: number; prices?: number[]; category: string; note?: string };
type CartLine = { product: Product; price: number; quantity: number };

const products: Product[] = [
  { id: 'potato-syrian', name: 'بطاطا سوري', price: 60, category: 'sandwiches', note: 'بطاطا مقرمشة، مخلل، صوص البيت' },
  { id: 'falafel-syrian', name: 'فلافل سوري', price: 60, category: 'sandwiches', note: 'فلافل سخنة، خضرة، طحينة' },
  { id: 'mix-falafel-potato', name: 'مكس فلافل وبطاطا', price: 70, category: 'sandwiches', note: 'خلطة على أصولها في عيش سوري' },
  { id: 'mix-potato-cheese', name: 'مكس بطاطا وجبنة', price: 70, category: 'sandwiches', note: 'جبنة سايحة وبطاطا متبّلة' },
  { id: 'harissa-cheese', name: 'هريسة مع جبنة', price: 50, category: 'sandwiches', note: 'هريسة شامية ولمسة جبنة' },
  { id: 'chicken-shawarma', name: 'شاورما فراخ', price: 120, category: 'grill', note: 'تتبيلة شامية ولفّة محمّصة' },
  { id: 'chicken-mozzarella', name: 'شاورما فراخ موزاريلا', price: 135, category: 'grill', note: 'شاورما فراخ وموزاريلا سايحة' },
  { id: 'meat-shawarma', name: 'شاورما لحم', price: 150, category: 'grill', note: 'لحم متبّل على الطريقة الشامية' },
  { id: 'chicken-burger', name: 'برجر فراخ', price: 120, category: 'grill', note: 'قرمشة غنية في عيش طري' },
  { id: 'kofta-sandwich', name: 'كفتة', price: 150, category: 'grill', note: 'كفتة مشوية بتوابل البيت' },
  { id: 'chicken-meal', name: 'وجبة شاورما فراخ سوري', price: 185, category: 'meals', note: 'وجبة دسمة بلمسة شامية' },
  { id: 'meat-meal', name: 'وجبة شاورما لحم', price: 220, category: 'meals', note: 'شاورما لحم مع إضافاتها' },
  { id: 'crispy-meal', name: 'وجبة كرسبي', prices: [200, 250], category: 'meals', note: 'اختار السعر المناسب لك' },
  { id: 'kofta-meal', name: 'وجبة كفتة', price: 200, category: 'meals', note: 'كفتة مشوية وتفاصيلها على مزاج الشام' },
  { id: 'tila-mix', name: 'وجبة ميكس تيلا', price: 300, category: 'meals', note: 'اختيارات من قلب المنيو في وجبة واحدة' },
  { id: 'pickles', name: 'علبة مخلل', price: 15, category: 'sides', note: 'مخلل بيتي يظبط اللقمة' },
  { id: 'garlic', name: 'علبة ثومية', price: 15, category: 'sides', note: 'ثومية كريمية على أصولها' },
  { id: 'masaha', name: 'مسحة', price: 50, category: 'sides', note: 'غموس شامي غني' },
  { id: 'fries', name: 'باكيت بطاطا', price: 50, category: 'sides', note: 'بطاطا سخنة ومقرمشة' },
  { id: 'cheese-borek', name: 'بورك جبنة', price: 45, category: 'sides', note: 'عجينة رقيقة وحشوة جبنة' },
  { id: 'meat-borek', name: 'بورك لحم', price: 49, category: 'sides', note: 'لقمة مقرمشة بحشوة لحم' },
  { id: 'kibbeh', name: 'كبة', price: 59, category: 'sides', note: 'كبة شامية متبّلة' },
];

const sections = [
  { id: 'sandwiches', title: 'السندوتشات السورية', short: 'سوري', intro: 'لقمة شامية على السريع' },
  { id: 'grill', title: 'سندوتش فراخ ولحم', short: 'شاورما', intro: 'من الشواية لعيشِك' },
  { id: 'meals', title: 'الوجبات', short: 'وجبات', intro: 'وجبة تلمّ اللمة' },
  { id: 'sides', title: 'المقبلات', short: 'إضافات', intro: 'تفاصيل صغيرة بتكمّلها' },
  { id: 'icecream', title: 'الآيس كريم', short: 'آيس كريم', intro: 'بيانات القسم قريبًا' },
  { id: 'drinks', title: 'المشروبات والبن', short: 'مشروبات', intro: 'بيانات القسم قريبًا' },
];

function BrandMark() {
  return <span className="brand-mark" aria-hidden="true"><span>ت</span><i /></span>;
}

function Home() {
  const [cart, setCart] = useState<CartLine[]>([]);
  const [activeCategory, setActiveCategory] = useState('sandwiches');
  const [mobileMenu, setMobileMenu] = useState(false);
  const [showCart, setShowCart] = useState(false);
  const [customer, setCustomer] = useState({ name: '', phone: '', address: '', fulfillment: 'delivery' });
  const [formError, setFormError] = useState('');
  const [confirmation, setConfirmation] = useState<Order | null>(null);
  const [copied, setCopied] = useState(false);
  const [mealPrices, setMealPrices] = useState<Record<string, number>>({});
  const createOrder = useCreateOrder({ request: { credentials: 'include' } });

  const itemCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const orderSummary = useMemo(() => {
    const lines = cart.map((line) => `${line.product.name}${line.product.id === 'crispy-meal' ? ` (${line.price} ج)` : ''} × ${line.quantity} — ${line.price * line.quantity} ج`);
    return `طلب تيلا الشام\n${lines.join('\n')}\nالإجمالي: ${total} ج\nالاسم: ${customer.name}\nالهاتف: ${customer.phone}\nطريقة الاستلام: ${customer.fulfillment === 'delivery' ? 'توصيل' : 'استلام'}${customer.fulfillment === 'delivery' ? `\nالعنوان: ${customer.address}` : ''}`;
  }, [cart, total, customer]);

  const changeQuantity = (product: Product, price: number, delta: number) => {
    setCart((current) => {
      const found = current.find((line) => line.product.id === product.id && line.price === price);
      if (!found && delta > 0) return [...current, { product, price, quantity: 1 }];
      return current.map((line) => line.product.id === product.id && line.price === price
        ? { ...line, quantity: line.quantity + delta }
        : line).filter((line) => line.quantity > 0);
    });
    setConfirmation(null);
  };

  const getQuantity = (product: Product, price: number) =>
    cart.find((line) => line.product.id === product.id && line.price === price)?.quantity ?? 0;

  const submitOrder = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!cart.length) { setFormError('أضف صنفًا واحدًا على الأقل قبل متابعة الطلب.'); return; }
    if (!customer.name.trim() || !customer.phone.trim() || (customer.fulfillment === 'delivery' && !customer.address.trim())) {
      setFormError('من فضلك أكمل الاسم ورقم الهاتف والعنوان للتوصيل.'); return;
    }
    setFormError('');
    setConfirmation(null);
    createOrder.mutate({
      data: {
        customerName: customer.name.trim(),
        phone: customer.phone.trim(),
        address: customer.fulfillment === 'delivery' ? customer.address.trim() : null,
        fulfillment: customer.fulfillment as 'delivery' | 'pickup',
        items: cart.map((line) => ({
          productId: line.product.id,
          quantity: line.quantity,
          selectedPrice: line.product.prices ? line.price : null,
        })),
      },
    }, {
      onSuccess: (savedOrder) => {
        setConfirmation(savedOrder);
        setCart([]);
      },
      onError: (error) => {
        setFormError(error instanceof Error ? error.message : 'تعذّر إرسال الطلب. حاول مرة أخرى.');
      },
    });
  };

  const copySummary = async () => {
    try {
      const text = confirmation
        ? `طلب تيلا الشام #${confirmation.id}\n${confirmation.items.map((item) => `${item.name} × ${item.quantity} — ${item.unitPrice * item.quantity} ج`).join('\n')}\nالإجمالي: ${confirmation.totalPrice} ج\nالاسم: ${confirmation.customerName}\nالهاتف: ${confirmation.phone}`
        : orderSummary;
      await navigator.clipboard.writeText(text);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2200);
    } catch {
      setFormError('تعذّر النسخ من المتصفح. يمكنك تحديد الملخص ونسخه يدويًا.');
    }
  };

  const jumpToMenu = () => document.getElementById('menu')?.scrollIntoView({ behavior: 'smooth' });

  return (
    <div className="tila-app" dir="rtl">
      <div className="topline"><span>أكل شامي على مزاجك</span><span className="topline-dot" /><span>سهل تختار، سهل تطلب</span><span className="topline-note">منيو تيلا الشام</span></div>
      <header className="site-header">
        <a className="brand" href="#home" aria-label="تيلا الشام، الرئيسية">
          <BrandMark /><span className="brand-copy"><strong>تيلا الشام</strong><small>طعم من قلب الشام</small></span>
        </a>
        <button className="mobile-menu-toggle" onClick={() => setMobileMenu(!mobileMenu)} aria-label={mobileMenu ? 'إغلاق القائمة' : 'فتح القائمة'} data-testid="button-mobile-menu">{mobileMenu ? <X /> : <ChevronDown />}</button>
        <nav className={`main-nav ${mobileMenu ? 'nav-open' : ''}`} aria-label="التنقل الرئيسي">
          <a href="#home" onClick={() => setMobileMenu(false)}>الرئيسية</a>
          <a href="#menu" onClick={() => setMobileMenu(false)}>المنيو</a>
          <a href="#cart" onClick={() => { setMobileMenu(false); setShowCart(true); }}>سلة الطلب</a>
          <a href="#contact" onClick={() => setMobileMenu(false)}>تواصل ومكاننا</a>
          <a href="/admin" onClick={() => setMobileMenu(false)}>بوابة العاملين</a>
        </nav>
        <button className="header-cart" onClick={() => { setShowCart(true); document.getElementById('cart')?.scrollIntoView({ behavior: 'smooth' }); }} data-testid="button-open-cart">
          <ShoppingBag size={17} /><span>سلة الطلب</span><b>{itemCount}</b>
        </button>
      </header>

      <main>
        <section className="hero" id="home">
          <div className="hero-copy">
            <div className="eyebrow"><span className="eyebrow-line" /> أكل سوري سريع.. بروح البيت</div>
            <h1>ريحة الشام،<br /><em>في كل لقمة.</em></h1>
            <p>سندوتش سخن، شاورما على أصولها، ووجبة تفتح النفس. اختار اللي بتحبه وخلي الباقي علينا.</p>
            <div className="hero-actions">
              <button className="button-primary" onClick={jumpToMenu} data-testid="button-explore-menu">اختار أكلك <ArrowLeft size={17} /></button>
              <a className="text-link" href="#our-way">حكاية تيلا <ArrowDown size={14} /></a>
            </div>
            <div className="hero-footnote"><Sparkles className="little-spark" size={17} /><span>متعمل بحب.. ويتاكل على طول</span></div>
          </div>
          <div className="hero-art">
            <div className="hero-image-wrap"><img src="/hero-syrian-wrap.jpg" alt="سندوتش سوري طازج مع مخلل وثومية" /></div>
            <div className="hero-sticker"><span>لقمة</span><b>شامية</b><span>على السريع</span></div>
            <div className="hero-caption"><span className="caption-rule" /> مذاق يعرف طريقه إلى القلب <small>01 / 04</small></div>
            <div className="hero-side-label">SYRIAN STREET FOOD · 01</div>
          </div>
        </section>

        <div className="ticker" aria-label="عبارات من تيلا الشام">
          <div className="ticker-track"><span>من الشام للقمة</span><Sparkles /><span>طازة ورايقة</span><Sparkles /><span>لقمة على كيفك</span><Sparkles /><span>من الشام للقمة</span><Sparkles /><span>طازة ورايقة</span><Sparkles /><span>لقمة على كيفك</span></div>
        </div>

        <section className="menu-section section-pad" id="menu">
          <div className="section-heading">
            <div><div className="eyebrow"><span className="eyebrow-line" /> اختار على مهلك</div><h2>المنيو <em>بتاعنا</em></h2></div>
            <p>اللي على بالَك هتلاقيه، واللي مش عارف تبدأ بإيه.. ابدأ من هنا.</p>
          </div>
          <div className="menu-layout">
            <aside className="menu-rail">
              <div className="rail-title">الأقسام <span>06</span></div>
              {sections.map((section, index) => (
                <a key={section.id} className={`rail-link ${activeCategory === section.id ? 'rail-active' : ''}`} href={`#${section.id}`} onClick={() => setActiveCategory(section.id)}>
                  <span className="rail-index">0{index + 1}</span><span>{section.short}</span><ArrowLeft size={14} />
                </a>
              ))}
              <div className="rail-note"><ChefHat size={18} /><span>كل لقمة بتحكي<br />حكاية من الشام.</span></div>
            </aside>
            <div className="menu-content">
              {sections.slice(0, 4).map((section, sectionIndex) => (
                <section className={`menu-category category-${section.id}`} id={section.id} key={section.id} onMouseEnter={() => setActiveCategory(section.id)}>
                  <div className="category-heading">
                    <span className="category-number">0{sectionIndex + 1}</span>
                    <div><h3>{section.title}</h3><p>{section.intro}</p></div>
                    <span className="category-count">{products.filter((item) => item.category === section.id).length} أصناف</span>
                  </div>
                  <div className="product-list">
                    {products.filter((item) => item.category === section.id).map((product, index) => {
                      const prices = product.prices ?? [product.price!];
                      return (
                        <article className="product-row" key={product.id} data-testid={`card-product-${product.id}`}>
                          <div className={`food-stamp stamp-${sectionIndex}`}><span>{product.name.slice(0, 1)}</span></div>
                          <div className="product-info"><h4>{product.name}</h4><p>{product.note}</p>{product.prices && <span className="price-note">اختار السعر قبل الإضافة</span>}</div>
                          <div className="product-buy">
                            {product.prices ? <div className="price-options" aria-label="اختيار سعر وجبة الكرسبي">
                              {prices.map((price) => <button key={price} className={`price-choice ${mealPrices[product.id] === price ? 'price-selected' : ''}`} onClick={() => setMealPrices((old) => ({ ...old, [product.id]: price }))} data-testid={`button-price-${product.id}-${price}`}>{price} ج</button>)}
                            </div> : <span className="product-price">{product.price}<small>ج</small></span>}
                            {prices.map((price) => getQuantity(product, price) > 0 ? (
                              <div className="quantity-control" key={price}>
                                <button aria-label={`تقليل ${product.name}`} onClick={() => changeQuantity(product, price, -1)} data-testid={`button-decrease-${product.id}-${price}`}><Minus size={13} /></button>
                                <span data-testid={`text-quantity-${product.id}-${price}`}>{getQuantity(product, price)}</span>
                                <button aria-label={`زيادة ${product.name}`} onClick={() => changeQuantity(product, price, 1)} data-testid={`button-increase-${product.id}-${price}`}><Plus size={13} /></button>
                              </div>
                            ) : null)}
                            {(product.prices ? (mealPrices[product.id] ? [mealPrices[product.id]] : []) : prices).map((price) => getQuantity(product, price) === 0 && (
                              <button className="add-button" key={price} aria-label={`أضف ${product.name}`} onClick={() => changeQuantity(product, price, 1)} data-testid={`button-add-${product.id}-${price}`}><Plus size={17} /><span>أضف</span></button>
                            ))}
                            {product.prices && !mealPrices[product.id] && <span className="choose-reminder">حدد السعر</span>}
                          </div>
                          {index === 0 && sectionIndex === 0 && <span className="product-tag">على مزاج الشام</span>}
                        </article>
                      );
                    })}
                  </div>
                </section>
              ))}
              <div className="coming-soon-grid">
                {sections.slice(4).map((section, index) => <section className="coming-card" id={section.id} key={section.id} onMouseEnter={() => setActiveCategory(section.id)}>
                  <div className="coming-icon">{index === 0 ? <Soup size={21} /> : <Utensils size={21} />}</div>
                  <span className="coming-kicker">قريبًا على المنيو</span><h3>{section.title}</h3>
                  <p>بيانات الأصناف والأسعار لهذا القسم بانتظار التحديث.</p><span className="coming-dash" />
                </section>)}
              </div>
            </div>
          </div>
        </section>

        <section className="story-strip" id="our-way">
          <div className="story-number">حكاية<br /><b>تيلا</b></div>
          <div className="story-copy"><span className="story-kicker">طعم الشام.. قريب منك</span><h2>مش مجرد أكل.<br /><em>دي لمّة صغيرة.</em></h2></div>
          <div className="story-detail"><Sparkles className="story-asterisk" size={23} /><p>اختار اللي بتحبه من منيو تيلا الشام، ورتّب طلبك بنفسك. كل حاجة واضحة: الأصناف، السعر، والكمية — من غير لف ولا حيرة.</p><a href="#menu">يلا نختار <ArrowLeft size={14} /></a></div>
          <div className="story-decoration" aria-hidden="true">شام</div>
        </section>

        <section className="order-section section-pad" id="cart">
          <div className="section-heading order-heading">
            <div><div className="eyebrow"><span className="eyebrow-line" /> آخر خطوة.. براحتك</div><h2>سلة <em>الطلب</em></h2></div>
            <p>راجع اختياراتك، وابعت طلبك للمطعم مباشرة. الأسعار النهائية يؤكدها النظام عند الحفظ.</p>
          </div>
          <div className="order-layout">
            <div className="order-summary-panel">
              <div className="panel-head"><div><ShoppingBasket size={19} /><h3>اختياراتك</h3></div><span>{itemCount} صنف</span></div>
              {cart.length ? <div className="cart-lines">
                {cart.map((line) => <div className="cart-line" key={`${line.product.id}-${line.price}`}>
                  <div className="cart-line-name"><strong>{line.product.name}</strong>{line.product.id === 'crispy-meal' && <small>السعر المختار: {line.price} ج</small>}</div>
                  <div className="cart-line-controls"><button onClick={() => changeQuantity(line.product, line.price, -1)} aria-label={`إنقاص ${line.product.name}`} data-testid={`button-cart-decrease-${line.product.id}`}><Minus size={12} /></button><span>{line.quantity}</span><button onClick={() => changeQuantity(line.product, line.price, 1)} aria-label={`زيادة ${line.product.name}`} data-testid={`button-cart-increase-${line.product.id}`}><Plus size={12} /></button></div>
                  <strong className="cart-line-total">{line.price * line.quantity} ج</strong>
                  <button className="remove-line" aria-label={`حذف ${line.product.name}`} onClick={() => setCart((current) => current.filter((entry) => !(entry.product.id === line.product.id && entry.price === line.price)))} data-testid={`button-remove-${line.product.id}`}><X size={15} /></button>
                </div>)}
              </div> : <div className="empty-cart"><div className="empty-cart-icon"><ShoppingBag size={24} /></div><h4>لسه مفيش حاجة في السلة</h4><p>اللقمة اللي على بالك مستنياك في المنيو.</p><a href="#menu">لف على المنيو <ArrowLeft size={14} /></a></div>}
              <div className="total-line"><span>الإجمالي</span><strong data-testid="text-cart-total">{total} <small>جنيه</small></strong></div>
              <p className="summary-disclaimer">يُحتسب السعر النهائي ويُحفظ الطلب على خادم المطعم عند الإرسال.</p>
            </div>
            <form className="customer-form" onSubmit={submitOrder}>
              <div className="form-title"><span>بياناتك</span><small>لا يبدأ الطلب إلا بعد تأكيد الحفظ</small></div>
              <label>الاسم بالكامل<input value={customer.name} onChange={(event) => setCustomer({ ...customer, name: event.target.value })} placeholder="اكتب اسمك" autoComplete="name" data-testid="input-customer-name" /></label>
              <label>رقم الهاتف<input type="tel" value={customer.phone} onChange={(event) => setCustomer({ ...customer, phone: event.target.value })} placeholder="رقم نتواصل به" autoComplete="tel" data-testid="input-customer-phone" /></label>
              <fieldset className="fulfillment-select"><legend>طريقة الاستلام</legend><div className="fulfillment-options">
                <label className={customer.fulfillment === 'delivery' ? 'fulfillment-active' : ''}><input type="radio" name="fulfillment" value="delivery" checked={customer.fulfillment === 'delivery'} onChange={() => setCustomer({ ...customer, fulfillment: 'delivery' })} data-testid="radio-delivery" /><span>توصيل</span></label>
                <label className={customer.fulfillment === 'pickup' ? 'fulfillment-active' : ''}><input type="radio" name="fulfillment" value="pickup" checked={customer.fulfillment === 'pickup'} onChange={() => setCustomer({ ...customer, fulfillment: 'pickup' })} data-testid="radio-pickup" /><span>استلام</span></label>
              </div></fieldset>
              {customer.fulfillment === 'delivery' && <label>عنوان التوصيل<input value={customer.address} onChange={(event) => setCustomer({ ...customer, address: event.target.value })} placeholder="المنطقة، الشارع، وأقرب علامة" autoComplete="street-address" data-testid="input-customer-address" /></label>}
              {formError && <p className="form-error" role="alert" data-testid="text-form-error">{formError}</p>}
              <button className="submit-order" type="submit" disabled={createOrder.isPending} data-testid="button-create-summary">{createOrder.isPending ? 'جارٍ إرسال الطلب...' : 'أرسل الطلب للمطعم'} <ArrowLeft size={16} /></button>
              {confirmation && <div className="confirmation-box" role="status" data-testid="status-order-confirmation">
                <div className="confirmation-title"><CircleCheck size={20} /><strong>وصل طلبك للمطعم يا {confirmation.customerName}.</strong></div>
                <p>تم حفظ الطلب بنجاح. رقم الطلب <bdi>#{confirmation.id}</bdi> — الإجمالي المعتمد {confirmation.totalPrice} جنيه.</p>
                <pre>{confirmation.items.map((item) => `${item.name} × ${item.quantity} — ${item.unitPrice * item.quantity} ج`).join('\n')}\nالإجمالي: ${confirmation.totalPrice} ج\nالاسم: ${confirmation.customerName}\nالهاتف: ${confirmation.phone}\nطريقة الاستلام: ${confirmation.fulfillment === 'delivery' ? 'توصيل' : 'استلام'}${confirmation.address ? `\nالعنوان: ${confirmation.address}` : ''}</pre>
                <button type="button" className="copy-button" onClick={copySummary} data-testid="button-copy-summary">{copied ? <Check size={15} /> : <Copy size={15} />}{copied ? 'تم نسخ الملخص' : 'انسخ تفاصيل الطلب'}</button>
              </div>}
            </form>
          </div>
        </section>

        <section className="contact-section" id="contact">
          <div className="contact-left"><div className="eyebrow"><span className="eyebrow-line" /> احنا هنا.. بس التفاصيل لسه</div><h2>خلّي بياناتنا<br /><em>على الرادار.</em></h2><p>عنوان المطعم ورقم التواصل وروابطنا الاجتماعية ستُضاف هنا فور اعتمادها.</p><div className="contact-status"><span className="status-dot" /> البيانات الرسمية قيد الإضافة</div></div>
          <div className="contact-cards">
            <div className="contact-card"><span className="contact-index">01</span><div><strong>العنوان</strong><p>سيُضاف موقع المطعم عند توفر العنوان المعتمد.</p></div><span className="contact-symbol"><MapPin size={17} /></span></div>
            <div className="contact-card"><span className="contact-index">02</span><div><strong>الهاتف</strong><p>رقم التواصل سيُضاف بعد اعتماده.</p></div><span className="contact-symbol"><Phone size={16} /></span></div>
            <div className="contact-card"><span className="contact-index">03</span><div><strong>السوشيال</strong><p>روابط الحسابات الرسمية ستظهر هنا قريبًا.</p></div><span className="contact-symbol"><Share2 size={16} /></span></div>
          </div>
        </section>
      </main>
      <footer className="site-footer"><a className="brand footer-brand" href="#home"><BrandMark /><span className="brand-copy"><strong>تيلا الشام</strong><small>طعم من قلب الشام</small></span></a><span>لقمتك الشامية.. على كيفك.</span><a href="#home">فوق تاني <ArrowDown size={13} /></a></footer>

      {showCart && <div className="cart-drawer-backdrop" onClick={() => setShowCart(false)} role="presentation">
        <aside className="cart-drawer" dir="rtl" onClick={(event) => event.stopPropagation()} aria-label="محتويات سلة الطلب">
          <div className="drawer-head"><div><ShoppingBag size={19} /><strong>سلتك يا شامي</strong></div><button onClick={() => setShowCart(false)} aria-label="إغلاق السلة" data-testid="button-close-cart"><X size={20} /></button></div>
          <p className="drawer-count">{itemCount} صنف في سلتك</p>
          {cart.length ? cart.map((line) => <div className="drawer-item" key={`${line.product.id}-${line.price}`}><div><strong>{line.product.name}</strong><small>{line.price} ج × {line.quantity}</small></div><b>{line.price * line.quantity} ج</b></div>) : <div className="drawer-empty">سلتك لسه فاضية.<br />ابدأ من المنيو وخلي اللقمة علينا.</div>}
          <div className="drawer-total"><span>الإجمالي</span><strong>{total} ج</strong></div>
          <button className="button-primary drawer-cta" onClick={() => { setShowCart(false); document.getElementById('cart')?.scrollIntoView({ behavior: 'smooth' }); }} data-testid="button-go-to-order">كمّل بيانات الطلب <ArrowLeft size={16} /></button>
        </aside>
      </div>}
    </div>
  );
}

function Router() {
  return <ErrorBoundary resetKey={useLocation()[0]}><Switch>
    <Route path="/" component={HomeRedirect} />
    <Route path="/admin" component={AdminGate} />
    <Route path="/sign-in/*?" component={SignInPage} />
    <Route path="/sign-up/*?" component={SignUpPage} />
    <Route component={NotFound} />
  </Switch></ErrorBoundary>;
}

const statuses: OrderStatus[] = ['new', 'accepted', 'preparing', 'ready', 'completed', 'cancelled'];
const statusLabels: Record<OrderStatus, string> = {
  new: 'طلب جديد',
  accepted: 'تم القبول',
  preparing: 'قيد التحضير',
  ready: 'جاهز',
  completed: 'مكتمل',
  cancelled: 'ملغي',
};

function errorStatus(error: unknown) {
  return typeof error === 'object' && error !== null && 'status' in error
    ? Number((error as { status?: unknown }).status)
    : undefined;
}

function formatDate(value: string) {
  return new Intl.DateTimeFormat('ar-EG', {
    dateStyle: 'medium',
    timeStyle: 'short',
  }).format(new Date(value));
}

function AdminGate() {
  const { isLoaded, isSignedIn } = useAuth();
  const [, setLocation] = useLocation();
  if (!isLoaded) return <div className="staff-loading" aria-label="جارٍ التحقق من جلسة الدخول"><span /><span /><span /></div>;
  if (!isSignedIn) return <main className="staff-auth-wall" dir="rtl">
    <BrandMark />
    <span className="staff-overline">مساحة فريق تيلا الشام</span>
    <h1>طلبات اليوم،<br /><em>في مكان واحد.</em></h1>
    <p>لوحة العاملين مخصصة لفريق المطعم. سجّل الدخول بحسابك المعتمد للمتابعة.</p>
    <button className="staff-primary" onClick={() => setLocation('/sign-in')} data-testid="button-admin-sign-in">تسجيل دخول العاملين <ArrowLeft size={17} /></button>
    <a href="/" className="staff-back">العودة إلى المنيو</a>
  </main>;
  return <OrdersDashboard />;
}

function OrdersDashboard() {
  const { user } = useUser();
  const { signOut } = useClerk();
  const [activeFilter, setActiveFilter] = useState<'all' | OrderStatus>('all');
  const [feedback, setFeedback] = useState('');
  const ordersQuery = useListOrders({
    query: {
      queryKey: getListOrdersQueryKey(),
      refetchInterval: 12000,
      refetchIntervalInBackground: true,
    },
    request: { credentials: 'include' },
  });
  const statusMutation = useUpdateOrderStatus({
    request: { credentials: 'include' },
    mutation: {
      onSuccess: () => {
        setFeedback('تم تحديث حالة الطلب.');
        void queryClient.invalidateQueries({ queryKey: getListOrdersQueryKey() });
      },
      onError: (error) => setFeedback(error instanceof Error ? error.message : 'تعذّر تحديث الحالة. حاول مجددًا.'),
    },
  });
  const orders = ordersQuery.data ?? [];
  const visibleOrders = activeFilter === 'all' ? orders : orders.filter((order) => order.status === activeFilter);
  const newCount = orders.filter((order) => order.status === 'new').length;
  const accessDenied = errorStatus(ordersQuery.error) === 403;

  return <div className="staff-app" dir="rtl">
    <header className="staff-header">
      <a className="brand" href="/" aria-label="العودة إلى تيلا الشام"><BrandMark /><span className="brand-copy"><strong>تيلا الشام</strong><small>لوحة الطلبات</small></span></a>
      <div className="staff-header-actions">
        <span className="staff-user"><span className="staff-avatar">{user?.firstName?.slice(0, 1) ?? 'ت'}</span><span>{user?.fullName ?? 'فريق تيلا'}</span></span>
        <button className="staff-signout" onClick={() => signOut({ redirectUrl: basePath || '/' })} data-testid="button-staff-sign-out"><LogOut size={15} /> خروج</button>
      </div>
    </header>
    <main className="staff-main">
      <div className="staff-heading">
        <div>
          <span className="staff-overline">مطبخ تيلا الشام <i /></span>
          <h1>الطلبات <em>الواردة</em></h1>
          <p>تابع كل طلب من لحظة وصوله إلى التسليم.</p>
        </div>
        <div className="live-indicator"><span className="live-dot" /><div><strong>تحديث مباشر</strong><small>تحديث تلقائي كل ١٢ ثانية</small></div></div>
      </div>
      {accessDenied ? <section className="staff-error access-denied" role="alert">
        <div className="error-mark">!</div><h2>هذه المساحة لفريق المطعم فقط</h2>
        <p>حسابك مسجّل، لكن لا يملك صلاحية عرض الطلبات. تواصل مع إدارة تيلا الشام إذا كنت من الفريق.</p>
        <button onClick={() => void ordersQuery.refetch()} className="staff-retry">إعادة المحاولة <RefreshCw size={15} /></button>
      </section> : <>
        <div className="staff-stats">
          <div className="stat-card stat-new"><span>طلبات جديدة</span><strong>{ordersQuery.isLoading ? '—' : newCount.toLocaleString('ar-EG')}</strong><small>بانتظار مراجعة الفريق</small></div>
          <div className="stat-card"><span>كل الطلبات</span><strong>{ordersQuery.isLoading ? '—' : orders.length.toLocaleString('ar-EG')}</strong><small>منذ بدء استقبال الطلبات</small></div>
          <div className="stat-card"><span>قيد التنفيذ</span><strong>{orders.filter((order) => ['accepted', 'preparing', 'ready'].includes(order.status)).length.toLocaleString('ar-EG')}</strong><small>مقبولة أو قيد التحضير</small></div>
          <button className="refresh-orders" onClick={() => void ordersQuery.refetch()} disabled={ordersQuery.isFetching} data-testid="button-refresh-orders"><RefreshCw size={16} className={ordersQuery.isFetching ? 'spin-icon' : ''} /> تحديث القائمة</button>
        </div>
        {feedback && <div className={`staff-feedback ${statusMutation.isError ? 'is-error' : 'is-success'}`} role="status"><span>{feedback}</span><button onClick={() => setFeedback('')} aria-label="إخفاء الرسالة"><X size={15} /></button></div>}
        {ordersQuery.isError && !accessDenied ? <section className="staff-error" role="alert">
          <h2>لم نتمكن من تحميل الطلبات</h2><p>{ordersQuery.error instanceof Error ? ordersQuery.error.message : 'حدث خطأ أثناء الاتصال بالخادم.'}</p>
          <button onClick={() => void ordersQuery.refetch()} className="staff-retry">حاول مرة أخرى <RefreshCw size={15} /></button>
        </section> : <>
          <nav className="status-filters" aria-label="تصفية الطلبات">
            <button className={activeFilter === 'all' ? 'filter-active' : ''} onClick={() => setActiveFilter('all')}>الكل <b>{orders.length}</b></button>
            {statuses.map((status) => <button key={status} className={`${activeFilter === status ? 'filter-active' : ''} filter-${status}`} onClick={() => setActiveFilter(status)}>{statusLabels[status]}<b>{orders.filter((order) => order.status === status).length}</b></button>)}
          </nav>
          {ordersQuery.isLoading ? <div className="order-skeletons" aria-label="جارٍ تحميل الطلبات">{[1, 2, 3].map((n) => <div className="order-skeleton" key={n}><span /><span /><span /><i /></div>)}</div>
            : visibleOrders.length === 0 ? <section className="orders-empty"><div className="empty-ring"><PackageCheck size={27} /></div><h2>{orders.length ? 'لا توجد طلبات في هذا التصنيف' : 'أول طلب على الأبواب'}</h2><p>{orders.length ? 'اختر تصنيفًا آخر لرؤية طلباته.' : 'ستظهر الطلبات الجديدة هنا فور إرسالها من المنيو.'}</p></section>
              : <section className="orders-list" aria-label="قائمة الطلبات">
                {visibleOrders.map((order) => <article className={`order-card ${order.status === 'new' ? 'order-unread' : ''}`} key={order.id} data-testid={`card-order-${order.id}`}>
                  <div className="order-card-top">
                    <div className="order-number"><span>طلب</span><strong><bdi>#{order.id}</bdi></strong>{order.status === 'new' && <i>جديد</i>}</div>
                    <span className={`order-status status-${order.status}`}><i />{statusLabels[order.status]}</span>
                  </div>
                  <div className="order-meta"><span><Clock3 size={14} /> {formatDate(order.createdAt)}</span><span className={`fulfillment-tag ${order.fulfillment}`}><span />{order.fulfillment === 'delivery' ? 'توصيل' : 'استلام من المطعم'}</span></div>
                  <div className="order-card-content">
                    <section className="customer-detail">
                      <span className="detail-kicker">بيانات العميل</span><h2>{order.customerName}</h2>
                      <a href={`tel:${order.phone}`} dir="ltr" className="customer-phone"><Phone size={13} />{order.phone}</a>
                      {order.address && <p className="customer-address"><MapPin size={14} />{order.address}</p>}
                    </section>
                    <section className="ordered-items">
                      <span className="detail-kicker">تفاصيل الطلب <b>{order.items.length} أصناف</b></span>
                      {order.items.map((item, index) => <div className="ordered-item" key={`${item.productId}-${index}`}><span><b>{item.quantity}×</b> {item.name}</span><strong>{(item.quantity * item.unitPrice).toLocaleString('ar-EG')} ج</strong></div>)}
                    </section>
                    <section className="order-total-block"><span>الإجمالي</span><strong>{order.totalPrice.toLocaleString('ar-EG')} <small>جنيه</small></strong></section>
                  </div>
                  <footer className="order-card-footer">
                    <span>آخر تحديث <bdi>{formatDate(order.updatedAt)}</bdi></span>
                    <label className="status-control">تحديث الحالة
                      <select value={order.status} disabled={statusMutation.isPending && statusMutation.variables?.id === order.id} onChange={(event) => {
                        setFeedback('');
                        statusMutation.mutate({ id: order.id, data: { status: event.target.value as OrderStatus } });
                      }} aria-label={`تغيير حالة الطلب ${order.id}`} data-testid={`select-order-status-${order.id}`}>
                        {statuses.map((status) => <option value={status} key={status}>{statusLabels[status]}</option>)}
                      </select>
                    </label>
                  </footer>
                </article>)}
              </section>}
        </>}
      </>}
    </main>
    <footer className="staff-footer"><span>تيلا الشام</span><span>طلباتٌ محفوظة، ومطبخٌ جاهز.</span></footer>
  </div>;
}

function HomeRedirect() {
  const { isLoaded, isSignedIn } = useAuth();
  if (!isLoaded || isSignedIn) return isLoaded ? <Redirect to="/admin" /> : <div className="staff-loading"><span /><span /><span /></div>;
  return <Home />;
}

function SignInPage() {
  return <AuthFrame><SignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} /></AuthFrame>;
}

function SignUpPage() {
  return <AuthFrame><SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`} /></AuthFrame>;
}

function AuthFrame({ children }: { children: ReactNode }) {
  return <main className="auth-frame" dir="rtl"><a href="/" className="auth-brand"><BrandMark /><span><strong>تيلا الشام</strong><small>طعم من قلب الشام</small></span></a><div className="auth-context"><span>فريق تيلا الشام</span><h1>اللمة تبدأ<br /><em>من هنا.</em></h1><p>دخول آمن لفريق المطعم لمتابعة الطلبات القادمة.</p></div><div className="auth-widget">{children}</div><a href="/" className="auth-home">العودة إلى المنيو <ArrowLeft size={14} /></a></main>;
}

function ClerkQueryClientCacheInvalidator() {
  const { addListener } = useClerk();
  const prevUserId = useMemo(() => ({ value: undefined as string | null | undefined }), []);
  useEffect(() => addListener(({ user }) => {
    const userId = user?.id ?? null;
    if (prevUserId.value !== undefined && prevUserId.value !== userId) queryClient.clear();
    prevUserId.value = userId;
  }), [addListener, prevUserId]);
  return null;
}

function ClerkProviderWithRoutes() {
  const [, setLocation] = useLocation();
  return <ClerkProvider
    publishableKey={clerkPubKey}
    proxyUrl={clerkProxyUrl}
    appearance={clerkAppearance}
    signInUrl={`${basePath}/sign-in`}
    signUpUrl={`${basePath}/sign-up`}
    localization={{
      signIn: { start: { title: 'أهلًا بعودتك', subtitle: 'سجّل الدخول لمتابعة طلبات المطعم' } },
      signUp: { start: { title: 'حساب فريق تيلا', subtitle: 'أنشئ حسابك للوصول إلى لوحة الطلبات' } },
    }}
    routerPush={(to) => setLocation(stripBase(to))}
    routerReplace={(to) => setLocation(stripBase(to), { replace: true })}
  >
    <QueryClientProvider client={queryClient}>
      <ClerkQueryClientCacheInvalidator />
      <TooltipProvider><Router /><Toaster /></TooltipProvider>
    </QueryClientProvider>
  </ClerkProvider>;
}

function App() {
  return <WouterRouter base={basePath}><ClerkProviderWithRoutes /></WouterRouter>;
}

export default App;
