import { createInsertSchema } from "drizzle-zod";
import { integer, jsonb, pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export type OrderFulfillmentValue = "delivery" | "pickup";
export type OrderStatusValue =
  | "new"
  | "accepted"
  | "preparing"
  | "ready"
  | "completed"
  | "cancelled";

export type OrderItemRecord = {
  productId: string;
  name: string;
  quantity: number;
  unitPrice: number;
};

export const ordersTable = pgTable("tila_orders", {
  id: serial("id").primaryKey(),
  customerName: text("customer_name").notNull(),
  phone: text("phone").notNull(),
  address: text("address"),
  fulfillment: text("fulfillment").$type<OrderFulfillmentValue>().notNull(),
  items: jsonb("items").$type<OrderItemRecord[]>().notNull(),
  totalPrice: integer("total_price").notNull(),
  status: text("status").$type<OrderStatusValue>().notNull().default("new"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date()),
});

export const insertOrderSchema = createInsertSchema(ordersTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertOrder = z.infer<typeof insertOrderSchema>;
export type OrderRecord = typeof ordersTable.$inferSelect;
